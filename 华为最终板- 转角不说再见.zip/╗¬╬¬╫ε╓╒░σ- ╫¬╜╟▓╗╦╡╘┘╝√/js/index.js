var Btn = document.getElementsByClassName("btn"),
  oSpan = document.querySelectorAll(".tab span"),
  aImg = document.getElementsByTagName("li"),
  oNum = document.getElementsByClassName("num"),
  numArr = ["一","二","三","四"],
  len = aImg.length,
  Boo = true,
  index = 0;
oNum[1].innerHTML = numArr[index];
oSpan[0].onclick = function () {
  this.className = "active";
  oSpan[1].className ="";
  Boo = true;
};
oSpan[1].onclick = function () {
  this.className = "active";
  oSpan[0].className ="";
  Boo = false;
};
Btn[0].Img = false;
Btn[0].onclick = changeImg;
Btn[1].Img = true;
Btn[1].onclick = changeImg;
function changeImg() {
  aImg[index].className = "";
  if(this.Img){ //下一张
    if(++index > len-1){
      if(Boo){
        index = 0;
      }else {
        index = len-1;
        alert("老铁，已经是最后一张。。。")
      }
      //Boo?index = 0:index = len - 1;
    }
  }else{//上一张
    if(--index < 0 ){
      if(Boo) {
        index = len-1;
      }else {
        index = 0;
        alert("老铁，前面没有了。。。");
      }
    }
  }
  aImg[index].className = "on";
  oNum[0].innerHTML = index + 1;
  oNum[1].innerHTML = numArr[index];
}
/* Btn[0].onclick = function () {
   aImg[index].className = "";
   index--;
   if(Boo) {
     if(index < 0) {
       index = len - 1;
     }
   }else {
     if(index < 0) {
       index = 0;
       alert("老铁，前面没有了。。。");
     }
   }
   aImg[index].className = "on";
   oNum[0].innerHTML = index + 1;
   oNum[1].innerHTML = numArr[index];
 };
 Btn[1].onclick = function () {
   aImg[index].className = "";
   index++;
   if(Boo) {
     if(index > len -1) {
       index = 0;
     }
   }else {
     if(index > len -1) {
       index = len -1;
       alert("老铁，已经是最后一张。。。");
     }
   }
   aImg[index].className = "on";
   oNum[0].innerHTML = index + 1;
   oNum[1].innerHTML = numArr[index];
 }*/
